from pyrogram import Client, filters
from pyrogram.types import Message
import os

api_id = int(os.getenv("API_ID"))
api_hash = os.getenv("API_HASH")
bot_token = os.getenv("BOT_TOKEN")
channel_username = os.getenv("CHANNEL_USERNAME")

app = Client("reaksiya-bot", api_id=api_id, api_hash=api_hash, bot_token=bot_token)

@app.on_message(filters.channel & filters.chat(channel_username))
async def react_to_new_post(client, message: Message):
    await message.react("🔥")

app.run()
